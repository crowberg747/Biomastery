# BioMastery - Permanent Deployment Guide

This guide outlines the steps to permanently deploy your BioMastery Next.js application to Vercel and connect it to your Neon PostgreSQL database.

## Prerequisites

1.  **Vercel Account:** You will need a Vercel account. If you don't have one, sign up at [vercel.com](https://vercel.com).
2.  **Neon Account & Database:** You should have your Neon PostgreSQL database ready, along with its connection string (which you provided earlier: `postgresql://neondb_owner:npg_vVYdxns4QfM7@ep-gentle-brook-a4dshh4e-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require`).
3.  **GitHub/GitLab/Bitbucket Account:** Vercel typically deploys from a Git repository. Ensure your project code is pushed to a repository on one of these platforms.
4.  **Project Code:** You will need the complete `biomastery` project directory that I have developed.

## Deployment Steps

### Step 1: Prepare Your Project

1.  **Download Project Files:** Ensure you have the entire `/home/ubuntu/biomastery` project directory.
2.  **Initialize Git (if not already):** If you haven't already, navigate to the project directory in your terminal and initialize a Git repository:
    ```bash
    cd path/to/your/biomastery
    git init
    git add .
    git commit -m "Initial commit of BioMastery project"
    ```
3.  **Push to Remote Repository:** Create a new repository on GitHub (or your preferred Git provider) and push your local repository to it.
    ```bash
    # Example for GitHub
    git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY_NAME.git
    git branch -M main
    git push -u origin main
    ```

### Step 2: Configure Environment Variables in Vercel

Before deploying, or immediately after starting the deployment process on Vercel, you need to set up the environment variables.

1.  **Log in to Vercel.**
2.  **Import Project:**
    *   Click on "Add New..." -> "Project".
    *   Import the Git repository you created in Step 1.
3.  **Configure Project:**
    *   Vercel should automatically detect it as a Next.js project.
    *   Before clicking "Deploy" (or during the configuration step), navigate to the "Environment Variables" section.
    *   Add the following environment variables:
        *   `DATABASE_URL`: Set this to your Neon PostgreSQL connection string.
            *   Value: `postgresql://neondb_owner:npg_vVYdxns4QfM7@ep-gentle-brook-a4dshh4e-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require`
        *   `NEXTAUTH_SECRET`: Generate a strong, random string to be used as the secret for NextAuth. You can use an online generator or a command like `openssl rand -base64 32` in your terminal.
            *   Example Value: `your_very_strong_and_unique_secret_here` (Replace this with your actual generated secret).

### Step 3: Deploy to Vercel

1.  **Build and Deployment Settings:**
    *   **Framework Preset:** Should be automatically set to Next.js.
    *   **Build Command:** Vercel usually defaults to `next build` or `pnpm build` if it detects `pnpm-lock.yaml`. Ensure this is correct. Your `package.json` uses `pnpm build` which is `next build`.
    *   **Output Directory:** Should be automatically detected (usually `.next`).
    *   **Install Command:** If you are using `pnpm` (as in this project), you might need to override the install command to `pnpm install`. Vercel often handles this automatically if a `pnpm-lock.yaml` file is present.
2.  **Click "Deploy".** Vercel will start building and deploying your application.

### Step 4: Run Database Migrations and Seeding (Post-Deployment)

Once the initial deployment is successful, your application will be live, but the database will be empty and might not have the latest schema.

The `prisma db push` and `prisma db seed` commands are typically run in a development or build environment, not directly on a serverless function after deployment. Vercel's serverless environment is ephemeral.

**Recommended approaches for schema migration and seeding with Vercel and Prisma:**

*   **Option 1: Local or CI/CD Execution (Recommended for `db push` and `db seed`):**
    *   Before a critical deployment or when schema changes, run `pnpm prisma db push` locally (or in a CI/CD pipeline) against your *production* Neon database. **Be very careful when doing this to avoid data loss if you are not using proper migration files.** For this project, we used `db push --accept-data-loss` for simplicity in the sandbox, but for production, you should ideally use `prisma migrate deploy` after generating migration files with `prisma migrate dev`.
    *   Similarly, run `pnpm prisma:seed` (which executes `tsx prisma/seed.ts`) locally or in a CI/CD pipeline connected to your production database to populate it with the initial curriculum.

*   **Option 2: Prisma Migrate (Production Best Practice):**
    1.  **Generate Migrations:** During development, instead of `db push`, use `pnpm prisma migrate dev --name your_migration_name`. This creates SQL migration files.
    2.  **Apply Migrations:** Vercel can sometimes run migration scripts as part of the build process if configured correctly in `package.json`. A common way is to add `prisma migrate deploy` to your build script in `package.json`: `"build": "prisma migrate deploy && next build"`.
    3.  **Seeding:** Seeding can be done via a custom script run once after deployment, or by integrating it into your application logic if appropriate (e.g., an admin panel action). For the initial seed, running it locally against the production DB (as in Option 1) is often the simplest for a one-time setup.

**For this project, given we used `db push`:**
1.  Ensure your local `.env` file points to your *production* Neon database temporarily.
2.  Run `pnpm prisma db push --accept-data-loss` locally. (Again, caution with `--accept-data-loss` on a database with important data).
3.  Run `pnpm prisma:seed` locally.
4.  Revert your local `.env` if needed.

Your Vercel deployment will then connect to the already-migrated and seeded database.

### Step 5: Test Your Deployed Application

1.  Access the URL provided by Vercel.
2.  Test all functionalities:
    *   User registration
    *   User login and logout
    *   Curriculum display
    *   Ensure data is being fetched correctly from your Neon database.

## Important Considerations

*   **`NEXTAUTH_SECRET`:** Ensure this is a strong, unique secret and is kept confidential.
*   **Database Security:** Your Neon database connection string contains credentials. Keep it secure and only use it in trusted environments (like Vercel environment variables).
*   **Error Handling & Logging:** Vercel provides logging for your serverless functions. Monitor these logs for any issues post-deployment.
*   **Custom Domain:** Once you're satisfied, you can assign a custom domain to your Vercel project.

This guide should help you get BioMastery deployed permanently. Let me know if you encounter any issues during this process!
