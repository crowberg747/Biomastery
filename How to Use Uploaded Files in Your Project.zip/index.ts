import { PrismaClient } from "@prisma/client";
import { NextApiRequest, NextApiResponse } from "next";

const prisma = new PrismaClient();

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method === "POST") {
    try {
      const { title, description, order } = req.body;
      if (!title || order === undefined) {
        return res
          .status(400)
          .json({ message: "Title and order are required" });
      }
      const newModule = await prisma.module.create({
        data: {
          title,
          description,
          order: parseInt(order),
        },
      });
      return res.status(201).json(newModule);
    } catch (error) {
      console.error("Failed to create module:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  } else if (req.method === "GET") {
    try {
      const modules = await prisma.module.findMany({
        orderBy: { order: "asc" },
        include: { lessons: { orderBy: { order: "asc" } } },
      });
      return res.status(200).json(modules);
    } catch (error) {
      console.error("Failed to retrieve modules:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  } else {
    res.setHeader("Allow", ["GET", "POST"]);
    return res.status(405).json({ message: `Method ${req.method} not allowed` });
  }
}

