"use client";

import { SessionProvider, useSession, signOut } from "next-auth/react";
import { Toaster } from "@/components/ui/sonner";
import Link from "next/link";
import { Button } from "@/components/ui/button"; // Assuming you have a Button component

function AppLayout({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession();
  const isLoading = status === "loading";

  return (
    <html lang="en">
      <body>
        <nav className="bg-gray-800 text-white p-4">
          <div className="container mx-auto flex justify-between items-center">
            <Link href="/" className="text-xl font-bold">BioMastery</Link>
            <div>
              {isLoading ? (
                <p>Loading...</p>
              ) : session?.user ? (
                <>
                  <span className="mr-4">Welcome, {session.user.name || session.user.email}!</span>
                  <Button onClick={() => signOut({ callbackUrl: "/auth/signin" })} variant="outline" className="mr-4 bg-transparent hover:bg-white hover:text-gray-800 text-white border-white">
                    Sign Out
                  </Button>
                  {/* Add other authenticated user links here, e.g., Profile */}
                </>
              ) : (
                <>
                  <Link href="/auth/signin" className="mr-4 hover:text-gray-300">Sign In</Link>
                  <Link href="/auth/register" className="hover:text-gray-300">Register</Link>
                </>
              )}
            </div>
          </div>
        </nav>
        <main className="container mx-auto p-4">
          {children}
        </main>
        <Toaster richColors />
      </body>
    </html>
  );
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SessionProvider>
      <AppLayout>{children}</AppLayout>
    </SessionProvider>
  );
}

