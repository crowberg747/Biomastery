mkdir -p /home/ubuntu/biomastery/src/app/auth/signin && mkdir -p /home/ubuntu/biomastery/src/app/auth/register && mkdir -p /home/ubuntu/biomastery/src/components/auth
