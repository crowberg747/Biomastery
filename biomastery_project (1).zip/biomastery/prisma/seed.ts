import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

const curriculumData = [
  {
    moduleOrder: 0,
    moduleTitle: 'Learning Science',
    moduleDescription: 'Active recall, spaced repetition, Pomodoro + Ultradian rhythm, habit stacking.',
    lessons: [
      { title: 'Introduction to Active Recall', explainer: 'Explainer for Active Recall (600-800 words).', order: 0 },
      { title: 'Understanding Spaced Repetition', explainer: 'Explainer for Spaced Repetition (600-800 words).', order: 1 },
      { title: 'The Pomodoro Technique', explainer: 'Explainer for Pomodoro (600-800 words).', order: 2 },
      { title: 'Ultradian Rhythms and Learning', explainer: 'Explainer for Ultradian Rhythms (600-800 words).', order: 3 },
      { title: 'Habit Stacking for Consistent Study', explainer: 'Explainer for Habit Stacking (600-800 words).', order: 4 },
    ],
  },
  {
    moduleOrder: 1,
    moduleTitle: 'Cellular Energy',
    moduleDescription: 'NAD⁺ salvage/de-novo, ATP production, CD38, NNMT, ROS.',
    lessons: [
      { title: 'NAD⁺ Metabolism Pathways', explainer: 'Explainer for NAD⁺ Metabolism (600-800 words).', order: 0 },
      { title: 'ATP: The Energy Currency', explainer: 'Explainer for ATP Production (600-800 words).', order: 1 },
      { title: 'The Role of CD38 in NAD⁺ Decline', explainer: 'Explainer for CD38 (600-800 words).', order: 2 },
      { title: 'NNMT and Metabolic Regulation', explainer: 'Explainer for NNMT (600-800 words).', order: 3 },
      { title: 'Reactive Oxygen Species (ROS) Balance', explainer: 'Explainer for ROS (600-800 words).', order: 4 },
    ],
  },
  {
    moduleOrder: 2,
    moduleTitle: 'Systems Biology',
    moduleDescription: 'AMPK vs mTOR, sirtuins, hormone axes.',
    lessons: [
      { title: 'AMPK and mTOR Signaling', explainer: 'Explainer for AMPK vs mTOR (600-800 words).', order: 0 },
      { title: 'Sirtuins: Longevity and Healthspan', explainer: 'Explainer for Sirtuins (600-800 words).', order: 1 },
      { title: 'Understanding Hormone Axes', explainer: 'Explainer for Hormone Axes (600-800 words).', order: 2 },
      { title: 'Integrative Systems Approaches', explainer: 'Explainer for Systems Approaches (600-800 words).', order: 3 },
      { title: 'Feedback Loops in Biological Systems', explainer: 'Explainer for Feedback Loops (600-800 words).', order: 4 },
    ],
  },
  {
    moduleOrder: 3,
    moduleTitle: 'Fascia & Integrative Anatomy',
    moduleDescription: 'Anatomy Trains lines, mechanotransduction, tendon continuum.',
    lessons: [
      { title: 'Introduction to Anatomy Trains', explainer: 'Explainer for Anatomy Trains (600-800 words).', order: 0 },
      { title: 'Mechanotransduction in Tissues', explainer: 'Explainer for Mechanotransduction (600-800 words).', order: 1 },
      { title: 'The Tendon Continuum Model', explainer: 'Explainer for Tendon Continuum (600-800 words).', order: 2 },
      { title: 'Fascia as a Sensory Organ', explainer: 'Explainer for Fascia as Sensory Organ (600-800 words).', order: 3 },
      { title: 'Integrative Movement and Fascia', explainer: 'Explainer for Integrative Movement (600-800 words).', order: 4 },
    ],
  },
  {
    moduleOrder: 4,
    moduleTitle: 'Training Science',
    moduleDescription: 'Galpin physiological domains, periodisation models, Huberman protocols.',
    lessons: [
      { title: 'Galpin\'s Physiological Domains', explainer: 'Explainer for Galpin Domains (600-800 words).', order: 0 },
      { title: 'Periodisation Models in Training', explainer: 'Explainer for Periodisation (600-800 words).', order: 1 },
      { title: 'Huberman Lab Training Protocols', explainer: 'Explainer for Huberman Protocols (600-800 words).', order: 2 },
      { title: 'Strength Training Principles', explainer: 'Explainer for Strength Training (600-800 words).', order: 3 },
      { title: 'Endurance Training Adaptations', explainer: 'Explainer for Endurance Training (600-800 words).', order: 4 },
    ],
  },
  {
    moduleOrder: 5,
    moduleTitle: 'Therapeutic Toolbox',
    moduleDescription: 'Cold/heat, light, HBOT, peptides, chrono-nutrition.',
    lessons: [
      { title: 'Cold and Heat Therapy Benefits', explainer: 'Explainer for Cold/Heat Therapy (600-800 words).', order: 0 },
      { title: 'Light Therapy (Photobiomodulation)', explainer: 'Explainer for Light Therapy (600-800 words).', order: 1 },
      { title: 'Hyperbaric Oxygen Therapy (HBOT)', explainer: 'Explainer for HBOT (600-800 words).', order: 2 },
      { title: 'Introduction to Peptides', explainer: 'Explainer for Peptides (600-800 words).', order: 3 },
      { title: 'Chrono-nutrition and Meal Timing', explainer: 'Explainer for Chrono-nutrition (600-800 words).', order: 4 },
    ],
  },
  {
    moduleOrder: 6,
    moduleTitle: 'Coaching & Communication',
    moduleDescription: 'Behaviour change, evidence grading, storytelling.',
    lessons: [
      { title: 'Models of Behaviour Change', explainer: 'Explainer for Behaviour Change (600-800 words).', order: 0 },
      { title: 'Grading Scientific Evidence', explainer: 'Explainer for Evidence Grading (600-800 words).', order: 1 },
      { title: 'The Art of Storytelling in Education', explainer: 'Explainer for Storytelling (600-800 words).', order: 2 },
      { title: 'Effective Communication Strategies', explainer: 'Explainer for Communication (600-800 words).', order: 3 },
      { title: 'Building Client Rapport and Trust', explainer: 'Explainer for Client Rapport (600-800 words).', order: 4 },
    ],
  },
];

async function main() {
  console.log(`Start seeding ...`);
  for (const mod of curriculumData) {
    const createdModule = await prisma.module.create({
      data: {
        title: mod.moduleTitle,
        description: mod.moduleDescription,
        order: mod.moduleOrder,
        lessons: {
          create: mod.lessons.map(lesson => ({
            title: lesson.title,
            explainer: lesson.explainer,
            order: lesson.order,
            // For demo purposes, we'll add some placeholder related data
            externalResources: {
              create: [
                { type: 'video', url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', title: 'Demo Video 1' },
                { type: 'paper', url: 'https://arxiv.org/abs/2305.12582', title: 'Demo Paper 1' },
              ]
            },
            flashcards: {
              create: [
                { question: 'What is the capital of this lesson?', answer: 'The main idea.' },
                { question: 'What is a key takeaway?', answer: 'An important concept.' },
              ]
            },
            quizItems: {
              create: [
                {
                  question: 'Which of these is a core concept?',
                  options: ['Option A', 'Option B (Correct)', 'Option C'],
                  correctOption: 1,
                },
                {
                  question: 'True or False: This lesson is important.',
                  options: ['True', 'False'],
                  correctOption: 0,
                },
              ]
            }
          })),
        },
      },
    });
    console.log(`Created module with id: ${createdModule.id}`);
  }
  console.log(`Seeding finished.`);
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });

