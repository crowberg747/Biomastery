"use client";

import { useEffect, useState } from 'react';
import { Module, Lesson, ExternalResource, Flashcard, QuizItem } from '@prisma/client';
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

interface LessonWithDetails extends Lesson {
  externalResources: ExternalResource[];
  flashcards: Flashcard[];
  quizItems: QuizItem[];
}

interface ModuleWithLessons extends Module {
  lessons: LessonWithDetails[];
}

async function fetchModules(): Promise<ModuleWithLessons[]> {
  const res = await fetch('/api/modules');
  if (!res.ok) {
    throw new Error('Failed to fetch modules');
  }
  return res.json();
}

export default function CurriculumPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [modules, setModules] = useState<ModuleWithLessons[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (status === "loading") return; // Do nothing while loading
    if (!session && status === "unauthenticated") {
      router.push("/auth/signin"); // Redirect to sign-in if not authenticated
      return;
    }

    if (session) { // Only fetch modules if authenticated
      async function loadModules() {
        try {
          setIsLoading(true);
          const data = await fetchModules();
          setModules(data);
          setError(null);
        } catch (err: any) {
          setError(err.message);
        } finally {
          setIsLoading(false);
        }
      }
      loadModules();
    }
  }, [session, status, router]);

  if (status === "loading" || isLoading) return <p>Loading curriculum...</p>;
  if (!session) return <p>Redirecting to sign in...</p>; // Or a more user-friendly message
  if (error) return <p>Error loading curriculum: {error}</p>;

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">BioMastery Curriculum</h1>
      {modules.length === 0 && !isLoading ? (
        <p>No modules available yet. The seed script might need to be run, or there is no content.</p>
      ) : (
        <div className="space-y-6">
          {modules.map((module) => (
            <div key={module.id} className="p-6 border rounded-lg shadow-md">
              <h2 className="text-2xl font-semibold mb-2">{module.title} (Module {module.order})</h2>
              <p className="text-gray-700 mb-4">{module.description}</p>
              {module.lessons && module.lessons.length > 0 ? (
                <ul className="space-y-3">
                  {module.lessons.map((lesson) => (
                    <li key={lesson.id} className="p-4 border rounded-md bg-gray-50">
                      <h3 className="text-xl font-medium mb-1">{lesson.title} (Lesson {lesson.order})</h3>
                      <p className="text-sm text-gray-600 mb-2 line-clamp-3">{lesson.explainer}</p>
                      {/* Further details like resources, flashcards, quizzes can be added here or linked to a separate lesson page */}
                    </li>
                  ))}
                </ul>
              ) : (
                <p>No lessons in this module yet.</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

