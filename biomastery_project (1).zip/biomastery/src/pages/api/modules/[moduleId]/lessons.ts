import { PrismaClient } from "@prisma/client";
import { NextApiRequest, NextApiResponse } from "next";

const prisma = new PrismaClient();

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const { moduleId } = req.query;

  if (typeof moduleId !== "string") {
    return res.status(400).json({ message: "Invalid module ID" });
  }

  if (req.method === "POST") {
    try {
      const { title, explainer, order, externalResources, flashcards, quizItems } = req.body;
      if (!title || !explainer || order === undefined) {
        return res
          .status(400)
          .json({ message: "Title, explainer, and order are required" });
      }

      const newLesson = await prisma.lesson.create({
        data: {
          title,
          explainer,
          order: parseInt(order),
          moduleId,
          // TODO: Handle creation of related externalResources, flashcards, quizItems if provided
        },
      });
      return res.status(201).json(newLesson);
    } catch (error) {
      console.error(`Failed to create lesson for module ${moduleId}:`, error);
      return res.status(500).json({ message: "Internal server error" });
    }
  } else if (req.method === "GET") {
    try {
      const lessons = await prisma.lesson.findMany({
        where: { moduleId },
        orderBy: { order: "asc" },
        include: { externalResources: true, flashcards: true, quizItems: true },
      });
      return res.status(200).json(lessons);
    } catch (error) {
      console.error(`Failed to retrieve lessons for module ${moduleId}:`, error);
      return res.status(500).json({ message: "Internal server error" });
    }
  } else {
    res.setHeader("Allow", ["GET", "POST"]);
    return res.status(405).json({ message: `Method ${req.method} not allowed` });
  }
}

